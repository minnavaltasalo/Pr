﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimesheetMobile.Models
{
    public class GpsLocationModel
    {
        public static double Latitude { get; set; }
        public static double Longitude { get; set; }
        public static double Altitude { get; set; }
    }
}
